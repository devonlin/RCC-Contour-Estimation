rm(list=ls()) 
#-------------------------------------------------------------------------------
#Packages
#-------------------------------------------------------------------------------
library(lhs)
library(EzGP)
library(laGP)
library(dplyr)
#------------------------------------------------------------------------------------
#dimensions
p = 4
q = 1
m=6
lz=1:m
#init and budget
n0=30 #total initial size for each level
n0_each=5 
N=150
nnew=N-n0
#iteration
nsim=50
#contour level
a =3.295
#epsilon of m_c0
epsilon = 0.006
#hyper par of grouping
del=0.5
#size of m_c0
n_M_c0=200
#size of design space
npred=100
#EzGP package values
tau=sqrt(.Machine$double.eps)
save.image("initial.RData")
#-------------------------------------------------------------------------------
load("AllThroughputs_summarized.Rda") 
data_HPC=data.frame(dat_summar)
Y_sn=data_HPC[,6]/data_HPC[,7]
summary(Y_sn)

data_HPC_trans=cbind(data_HPC[,1]/1000000,log2(data_HPC[,2:3]),data_HPC[,4],as.numeric(as.factor(data_HPC[,5])),log(Y_sn),1:(nrow(data_HPC)))
colnames(data_HPC_trans)=c("Fre1","File","Rec","Num.th","Test","Y_sn","id")

#scale 0-1
Stand_DD<-apply(data_HPC_trans[,1:4],2,function(x) (x-min(x))/max(x-min(x)) )
data_HPC_scaled=as.matrix(cbind(Stand_DD,data_HPC_trans[,5:6],1:nrow(data_HPC_trans)))
colnames(data_HPC_scaled)=c("Fre1","File","Rec","Num.th","Test","Y_sn","id")
write.csv(data_HPC_scaled,file = "data_HPC_scaled.csv")


data_HPC_scaled=as.matrix(read.csv("data_HPC_scaled.csv")[,2:(p+q+3)])




  
  
#-------------------------------------------------------------------------------
#n0
#-------------------------------------------------------------------------------
#same initial for each level as the data of quantitative is the same 
data_generate=function(n0_each, p, lz) {
  x0 <- randomLHS(n0_each,p)
  z <- as.matrix(lz, length(lz), center=F)
  x <- matrix(x0,nrow(z)*n0_each, ncol(x0) ,byrow=T)
  TT <- rep(1:nrow(z), each=n0_each)
  z <- z[TT]
  data <- NULL
  data$x0 <- x0
  data$x= x
  data$z= z
  data$TT <- TT
  data
} 

for(j in 1:nsim){
  id_HPC=c()
  W_dat=matrix(NA, ncol =p+q,nrow=n0)
   W_dat_C=data_generate(n0_each,p,lz)
   W_dat[,1:(p)]=W_dat_C$x
   W_dat[,(p+1):(p+q)]=(rep(1:m,each=n0_each))
 colnames(W_dat)=c("x1","x2","x3","x4","z")
  for(io in 1:prod(m)){
          W_LHD_z_i=as.matrix(data.frame(W_dat) %>% filter(z ==io ))
          data_z_i=as.matrix(data.frame(data_HPC_scaled) %>% filter(Test ==io ))
          for(ip in 1:(table(W_dat[,(p+1):(p+q)])[io])){
            #find closest distance between W_LHD and data_z_i
            dist_init=distance(data_z_i[,1:p],matrix(W_LHD_z_i[ip,1:p],nrow=1))
            id_z=which.min(dist_init)
            id=data_z_i[id_z,p+q+2]
            data_z_i=data_z_i[-id_z,]
            id_HPC=c(id_HPC,id)
          }
      }

  n0_dat=data_HPC_scaled[id_HPC,]
  filename= paste0("n0_dat","_",j,".csv",sep="")
  write.csv(n0_dat,file=filename)
  
  }


